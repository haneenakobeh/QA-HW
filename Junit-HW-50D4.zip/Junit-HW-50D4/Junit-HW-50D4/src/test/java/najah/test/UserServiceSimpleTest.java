package najah.test;

import najah.code.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.parallel.Execution;
import org.junit.jupiter.api.parallel.ExecutionMode;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("UserService Tests")
@Execution(ExecutionMode.CONCURRENT)
public class UserServiceSimpleTest {

	UserService Service;

	@BeforeEach
	void setUp() throws Exception {
		Service = new UserService();
	}

	@Test
	@DisplayName("Valid email test")
	void testValidEmail() {
		assertTrue(Service.isValidEmail("user@example.com"));
	}

	@Test
	@DisplayName("Invalid email test")
	void testInvalidEmail() {
		assertFalse(Service.isValidEmail("userExample.com"));
	}

	@Test
	@DisplayName("Authentication Success")
	void testAuthenticationSuccess() {
		assertTrue(Service.authenticate("admin", "1234"));
	}

	@Test
	@DisplayName("Authentication Failure")
	void testAuthenticationFailure() {
		assertFalse(Service.authenticate("admin", "1382073"));
	}

	@Test
	@DisplayName("Timeout Test")
	@Timeout(value = 500, unit = TimeUnit.MILLISECONDS)
	void testValidEmailWithTimeout() {
		assertTrue(Service.isValidEmail("user@example.com"));
	}

	@ParameterizedTest
	@CsvSource({
			"admin, 1234, true",
			"admin, 1382073, false",
			"user, password123, false"
	})
	@DisplayName("Parameterized test for authentication with different username and password combinations")
	void testAuthenticationWithParams(String username, String password, boolean expectedResult) {
		assertEquals(expectedResult, Service.authenticate(username, password));
	}
}
