package najah.test;

import najah.code.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("RecipeBook Tests")
public class RecipeBookTest {

    RecipeBook book;
    Recipe recipe;

    @BeforeEach
    void setUp() throws Exception {
        book = new RecipeBook();
        recipe = new Recipe();
        recipe.setName("Coffee");
        recipe.setPrice("10");
        recipe.setAmtCoffee("2");
        recipe.setAmtMilk("1");
        recipe.setAmtSugar("1");
        recipe.setAmtChocolate("0");
    }

    @Test
    @DisplayName("Add valid recipe")
    void testAddRecipe() {
        boolean added = book.addRecipe(recipe);
        assertTrue(added);
    }

    @Test
    @DisplayName("Add duplicate recipe")
    void testDuplicateRecipe() {
        book.addRecipe(recipe);
        assertFalse(book.addRecipe(recipe));
    }

    @Test
    @DisplayName("Delete recipe by index")
    void testDeleteRecipe() {
        book.addRecipe(recipe);
        String name = book.deleteRecipe(0);
        assertEquals("Coffee", name);
    }

    @Test
    @DisplayName("Delete with invalid index throws exception")
    void testDeleteInvalidIndexThrows() {
        book.addRecipe(recipe);
        assertThrows(ArrayIndexOutOfBoundsException.class, () -> book.deleteRecipe(5));
    }

    @Test
    @DisplayName("Set price with leading zeros")
    void testSetPriceLeadingZeros() throws RecipeException {
        recipe.setPrice("007");
        assertEquals(7, recipe.getPrice());
    }

    @Test
    @DisplayName("Test equals with same recipe values")
    void testEqualsWithSameRecipe() throws RecipeException {
        Recipe r1 = new Recipe();
        r1.setName("Cappuccino");
        r1.setPrice("12");
        r1.setAmtCoffee("2");
        r1.setAmtMilk("1");
        r1.setAmtSugar("1");
        r1.setAmtChocolate("1");

        Recipe r2 = new Recipe();
        r2.setName("Cappuccino");
        r2.setPrice("12");
        r2.setAmtCoffee("2");
        r2.setAmtMilk("1");
        r2.setAmtSugar("1");
        r2.setAmtChocolate("1");

        assertEquals(r1, r2);
    }

    @Test
    @DisplayName("Add recipe with high values")
    void testAddRecipeWithHighValues() throws Exception {
        Recipe highRecipe = new Recipe();
        highRecipe.setName("StrongCoffee");
        highRecipe.setPrice("9999");
        highRecipe.setAmtCoffee("50");
        highRecipe.setAmtMilk("50");
        highRecipe.setAmtSugar("50");
        highRecipe.setAmtChocolate("50");

        assertTrue(book.addRecipe(highRecipe));
        assertEquals(9999, highRecipe.getPrice());
    }

    @Test
    @DisplayName("Add recipe with special characters in name")
    void testRecipeNameSpecialCharacters() throws Exception {
        recipe.setName("Espresso Deluxe #1!");
        assertEquals("Espresso Deluxe #1!", recipe.getName());
    }

    @Test
    @DisplayName("Edit recipe at index")
    void testEditRecipe() throws Exception {
        book.addRecipe(recipe);
        Recipe newRecipe = new Recipe();
        newRecipe.setName("Latte");
        newRecipe.setPrice("15");
        newRecipe.setAmtCoffee("3");
        newRecipe.setAmtMilk("2");
        newRecipe.setAmtSugar("1");
        newRecipe.setAmtChocolate("1");
        String result = book.editRecipe(0, newRecipe);
        assertEquals("Coffee", result);
    }

    @ParameterizedTest
    @ValueSource(strings = {"Tea", "Latte", "Espresso"})
    @DisplayName("Test adding recipes with different names")
    void testAddRecipeWithDifferentNames(String name) {
        recipe.setName(name);
        boolean added = book.addRecipe(recipe);
        assertTrue(added, "Recipe with name " + name + " should be added successfully");
    }


    @Test
    @DisplayName("Compare two recipes field by field")
    void testCompareTwoRecipesFieldByField() throws Exception {
        book.addRecipe(recipe);
        Recipe retrievedRecipe = book.getRecipes()[0];

        assertNotNull(retrievedRecipe);
        assertEquals(recipe.getName(), retrievedRecipe.getName());
        assertEquals(recipe.getPrice(), retrievedRecipe.getPrice());
        assertEquals(recipe.getAmtCoffee(), retrievedRecipe.getAmtCoffee());
        assertEquals(recipe.getAmtMilk(), retrievedRecipe.getAmtMilk());
        assertEquals(recipe.getAmtSugar(), retrievedRecipe.getAmtSugar());
        assertEquals(recipe.getAmtChocolate(), retrievedRecipe.getAmtChocolate());
    }

    @Test
    @DisplayName("Test Recipe Getters")
    void testRecipeGetters() throws Exception {
        recipe.setName("Mocha");
        recipe.setPrice("20");
        recipe.setAmtCoffee("3");
        recipe.setAmtMilk("2");
        recipe.setAmtSugar("2");
        recipe.setAmtChocolate("1");

        assertEquals("Mocha", recipe.getName());
        assertEquals(20, recipe.getPrice());
        assertEquals(3, recipe.getAmtCoffee());
        assertEquals(2, recipe.getAmtMilk());
        assertEquals(2, recipe.getAmtSugar());
        assertEquals(1, recipe.getAmtChocolate());
    }

    @Test
    @DisplayName("Set zero values")
    void testSetZeroValues() throws Exception {
        recipe.setAmtCoffee("0");
        recipe.setAmtMilk("0");
        recipe.setAmtSugar("0");
        recipe.setAmtChocolate("0");

        assertEquals(0, recipe.getAmtCoffee());
        assertEquals(0, recipe.getAmtMilk());
        assertEquals(0, recipe.getAmtSugar());
        assertEquals(0, recipe.getAmtChocolate());
    }

    @Test
    @DisplayName("Test equals with null and different object types")
    void testEqualsNullAndOtherType() {
        assertNotEquals(recipe, null);
        assertNotEquals(recipe, "Not a recipe");
    }

    @Test
    @DisplayName("Add maximum allowed recipes")
    void testAddMaxRecipes() throws RecipeException {
        for (int i = 0; i < 4; i++) {
            Recipe r = new Recipe();
            r.setName("Drink" + i);
            r.setPrice("5");
            r.setAmtCoffee("1");
            r.setAmtMilk("1");
            r.setAmtSugar("1");
            r.setAmtChocolate("1");
            assertTrue(book.addRecipe(r));
        }

        Recipe extra = new Recipe();
        extra.setName("Extra");
        extra.setPrice("5");
        extra.setAmtCoffee("1");
        extra.setAmtMilk("1");
        extra.setAmtSugar("1");
        extra.setAmtChocolate("1");

        assertFalse(book.addRecipe(extra), "Should not be able to add more than 4 recipes");
    }

    @Test
    @DisplayName("Test invalid amount input in Recipe")
    void testInvalidAmountInRecipe() {
        assertThrows(RecipeException.class, () -> recipe.setAmtCoffee("-1"));
        assertThrows(RecipeException.class, () -> recipe.setAmtMilk("abc"));
    }

    @Test
    @DisplayName("Set negative value throws RecipeException")
    void testNegativePriceThrows() {
        assertThrows(RecipeException.class, () -> recipe.setPrice("-5"));
    }

    @Test
    @DisplayName("Set empty string as amount throws RecipeException")
    void testEmptyStringThrows() {
        assertThrows(RecipeException.class, () -> recipe.setAmtSugar(""));
    }

    @Test
    @DisplayName("Set non-integer strings as ingredients")
    void testNonIntegerInputs() {
        assertThrows(RecipeException.class, () -> recipe.setAmtMilk("two"));
        assertThrows(RecipeException.class, () -> recipe.setPrice("ten"));
    }

    @Test
    @DisplayName("Set whitespace as input throws RecipeException")
    void testWhitespaceInput() {
        assertThrows(RecipeException.class, () -> recipe.setAmtSugar(" "));
    }

    @Test
    @DisplayName("Timeout test")
    @Timeout(value = 500, unit = TimeUnit.MILLISECONDS)
    void timeoutTest() {
        book.addRecipe(recipe);
    }
}
