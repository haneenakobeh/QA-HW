package najah.test;


import najah.code.Calculator;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@DisplayName("Calculator Tests")
public class CalculatorTest {
	
    Calculator calc;

	@BeforeAll
	static void initialize() {
		System.out.println("Starting Calculator Tests");
	}

	@AfterAll
	static void tearDownAll() {
		System.out.println("Ending Calculator Tests");
	}



	@BeforeEach
	void setUp() throws Exception {
		calc = new Calculator();
		System.out.println("Setup Complete");
	}

	void tearDown() {
		System.out.println("Test Finished");
	}


	@Test
	@Order(1)
	@DisplayName("Test addition of multiple numbers")
	void testAdd(){
		int result = calc.add(1,2,3);
		assertEquals(6,result,"sum should be 6");
	}


	@Test
	@Order(2)
	@DisplayName("Test divide with valid input")
	void testDivide(){
		assertEquals(3, calc.divide(12,4));
	}


	@Test
	@Order(3)
	@DisplayName("Test divide by zero")
	void testDivideByZero(){
		assertThrows(ArithmeticException.class, () -> calc.divide(5,0));
	}


	@ParameterizedTest
	@ValueSource(ints = {0,1,5})
	@Order(4)
	@DisplayName("Test factorial for non-negative numbers")
	void testFactorial(int input){
		assertTrue(calc.factorial(input)>=0);
	}


	@Test
	@DisplayName("Test factorial with negative input")
	void testNegativeFactorial() {
		assertThrows(IllegalArgumentException.class, () -> calc.factorial(-5));
	}

	@Test
	@Order(6)
	@DisplayName("Timeout test")
	@Timeout(value = 500, unit = TimeUnit.MILLISECONDS)
	void timeoutTest(){
		try {
			Thread.sleep(300);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		calc.add(100,200);
	}



	@Test
	@Order(7)
	@Disabled("Intentional failure. Fix: change expected value to actual result.")
	void disabledFailingTest(){
		assertEquals(100, calc.add(30, 20));
	}
}

